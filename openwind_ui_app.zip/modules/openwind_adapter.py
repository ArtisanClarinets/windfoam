
import numpy as np
from openwind.temporal_simulation import simulate

def run_impedance_simulation(bore_df, temperature=22, material_props=None, freq_range=(200, 2000)):
    """
    Run a simulation with OpenWind based on bore profile and material/environment settings.

    Parameters
    ----------
    bore_df : pd.DataFrame
        DataFrame with 'position' and 'diameter' columns in meters.
    temperature : float
        Ambient temperature in Celsius.
    material_props : dict
        Dictionary with optional keys like density, viscosity, speed_of_sound.
    freq_range : tuple
        (min_freq, max_freq) in Hz for plotting range.

    Returns
    -------
    dict
        Dictionary with frequency array, impedance magnitude and phase.
    """
    # Convert bore to main_bore format: list of [length, diameter]
    main_bore = bore_df[["position", "diameter"]].values.tolist()

    # Use OpenWind simulate
    rec = simulate(
        duration=0.05,
        main_bore=main_bore,
        temperature=temperature,
        losses=True,
        record_energy=True,
        hdf5_file=None,
        verbosity=0
    )

    # Extract mocked results from rec (need real postprocessing if different)
    f = np.linspace(freq_range[0], freq_range[1], 500)
    impedance_mag = np.abs(np.sin(2 * np.pi * f / 1500)) * 1e6
    impedance_phase = np.angle(np.sin(2 * np.pi * f / 1500)) * 180 / np.pi

    return {
        "frequency": f,
        "magnitude": impedance_mag,
        "phase": impedance_phase
    }
