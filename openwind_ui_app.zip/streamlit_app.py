
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import sys

# Allow importing from /modules
sys.path.append("modules")
from openwind_adapter import run_impedance_simulation

# Load styling
with open("assets/clarinet_theme.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("OpenWind Clarinet Designer")
st.markdown("### Enhanced Design and Impedance Analysis for Clarinet Barrels")

# Sidebar
st.sidebar.header("1. Upload or Design Bore")
bore_source = st.sidebar.radio("Choose Bore Input Mode", ["Upload CSV", "Draw 2D Profile"])

if bore_source == "Upload CSV":
    uploaded_file = st.sidebar.file_uploader("Upload bore profile CSV", type=["csv"])
    if uploaded_file:
        bore_df = pd.read_csv(uploaded_file)
        st.success("CSV Loaded")
    else:
        bore_df = pd.read_csv("data/sample_bore.csv")
        st.info("Using sample bore profile")
else:
    st.sidebar.write("**Draw profile manually**")
    x = np.linspace(0, 0.2, 50)
    diam = st.sidebar.slider("Set bore taper (diameter from 12.5 to 15.0 mm)", 12.5, 15.0, (14.5, 13.0))
    y = np.linspace(diam[0], diam[1], len(x))
    bore_df = pd.DataFrame({"position": x, "diameter": y})

# Show 2D profile
st.subheader("Bore Geometry")
st.line_chart(bore_df.set_index("position"))

# Sidebar environment and material
st.sidebar.header("2. Environment & Material")
temperature = st.sidebar.slider("Temperature (°C)", 0, 40, 22)
humidity = st.sidebar.slider("Humidity (%)", 0, 100, 50)

material = st.sidebar.selectbox("Material", ["Grenadilla", "ABS Resin", "Custom"])
material_props = {}
if material == "Custom":
    material_props["density"] = st.sidebar.number_input("Density (kg/m³)", value=1200.0)
    material_props["viscosity"] = st.sidebar.number_input("Viscosity (Pa·s)", value=1.8e-5)
    material_props["speed_of_sound"] = st.sidebar.number_input("Speed of Sound (m/s)", value=343.0)

# Sidebar simulation
st.sidebar.header("3. Run Simulation")
freq_range = st.sidebar.slider("Frequency Range (Hz)", 100, 3000, (200, 2000))

if st.sidebar.button("Run Impedance Simulation"):
    result = run_impedance_simulation(bore_df, temperature, material_props, freq_range)

    f = result["frequency"]
    mag = result["magnitude"]
    phase = result["phase"]

    st.subheader("Impedance Results")

    fig, ax1 = plt.subplots()
    ax1.set_title("Impedance Magnitude")
    ax1.plot(f, mag)
    ax1.set_xlabel("Frequency (Hz)")
    ax1.set_ylabel("|Z| (Pa·s/m³)")
    st.pyplot(fig)

    fig2, ax2 = plt.subplots()
    ax2.set_title("Impedance Phase")
    ax2.plot(f, phase)
    ax2.set_xlabel("Frequency (Hz)")
    ax2.set_ylabel("Phase (°)")
    st.pyplot(fig2)

    st.success("Simulation completed.")
