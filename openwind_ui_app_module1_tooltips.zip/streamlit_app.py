
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import sys

sys.path.append("modules")
from openwind_adapter import run_impedance_simulation

with open("assets/clarinet_theme.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("OpenWind Clarinet Designer")
st.markdown("#### Bore Geometry, Simulation & Impedance Analysis")

st.sidebar.header("1. Bore Input")
bore_source = st.sidebar.radio(
    "How would you like to define the bore geometry?",
    ["Upload CSV", "Draw 2D Profile"],
    help="Choose to upload your own measurements or interactively draw a simple taper."
)

if bore_source == "Upload CSV":
    uploaded_file = st.sidebar.file_uploader(
        "Upload bore profile CSV",
        type=["csv"],
        help="Upload a CSV with two columns: position (m) and diameter (m)."
    )
    if uploaded_file:
        bore_df = pd.read_csv(uploaded_file)
        st.success("CSV Loaded")
    else:
        bore_df = pd.read_csv("data/sample_bore.csv")
        st.info("Using sample bore profile")
else:
    st.sidebar.markdown("**Draw a simple linear profile**")
    x = np.linspace(0, 0.2, 50)
    diam = st.sidebar.slider(
        "Set bore taper (diameter at start and end, in mm)",
        12.5, 15.0, (14.5, 13.0),
        help="This defines the bore's start and end diameters across 20cm length."
    )
    y = np.linspace(diam[0], diam[1], len(x))
    bore_df = pd.DataFrame({"position": x, "diameter": y})
    bore_df["diameter"] /= 1000  # convert to meters

st.subheader("Bore Profile")
st.line_chart(bore_df.set_index("position"))

st.sidebar.header("2. Environment & Material")
temperature = st.sidebar.slider(
    "Ambient Temperature (°C)", 0, 40, 22,
    help="Affects speed of sound and loss modeling inside the bore."
)
humidity = st.sidebar.slider(
    "Relative Humidity (%)", 0, 100, 50,
    help="Used for realistic air property modeling."
)

material = st.sidebar.selectbox(
    "Material", ["Grenadilla", "ABS Resin", "Custom"],
    help="Choose the clarinet barrel material to simulate acoustic behavior."
)
material_props = {}
if material == "Custom":
    material_props["density"] = st.sidebar.number_input(
        "Material Density (kg/m³)", value=1200.0,
        help="Mass per unit volume. Typical wood: ~1100–1300 kg/m³"
    )
    material_props["viscosity"] = st.sidebar.number_input(
        "Air Viscosity (Pa·s)", value=1.8e-5,
        help="Dynamic viscosity of air or medium inside bore."
    )
    material_props["speed_of_sound"] = st.sidebar.number_input(
        "Speed of Sound (m/s)", value=343.0,
        help="Set to 343 m/s for air at 20°C, adjust if different."
    )

st.sidebar.header("3. Simulation Settings")
freq_range = st.sidebar.slider(
    "Frequency Range (Hz)", 100, 3000, (200, 2000),
    help="Frequencies for which impedance will be computed."
)

if st.sidebar.button("Run Impedance Simulation"):
    result = run_impedance_simulation(bore_df, temperature, material_props, freq_range)
    f = result["frequency"]
    mag = result["magnitude"]
    phase = result["phase"]

    st.subheader("Simulation Results")

    st.markdown("**Impedance Magnitude**")
    fig1, ax1 = plt.subplots()
    ax1.plot(f, mag)
    ax1.set_xlabel("Frequency (Hz)")
    ax1.set_ylabel("|Z| (Pa·s/m³)")
    st.pyplot(fig1)

    st.markdown("**Impedance Phase**")
    fig2, ax2 = plt.subplots()
    ax2.plot(f, phase)
    ax2.set_xlabel("Frequency (Hz)")
    ax2.set_ylabel("Phase (°)")
    st.pyplot(fig2)

    st.success("Simulation completed.")
